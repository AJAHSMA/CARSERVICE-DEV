package com.ajahsma.enumeration;

public class NomenclatureCheckType {

}
