package com.ajahsma.carservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ajahsma.carservice.model.Designation;
import com.ajahsma.carservice.service.DesignationManager;
import com.onlinetutorialspoint.model.Person;

@Controller("designationController")
@RequestMapping(value = "/designation")
public class DesignationController {

	@Autowired
    private ApplicationContext applicationContext;
	
	@Autowired
	private DesignationManager designationManager;

	
	 @RequestMapping("/hello")
	    public String hello(@RequestParam(value="key", required=false, defaultValue="World") String name, Model model) {

	        String[] beanNames = applicationContext.getBeanDefinitionNames();

	        for (String beanName : beanNames) {

	            System.out.println(beanName + " : " + applicationContext.getBean(beanName).getClass().toString());
	        }

	        model.addAttribute("name", name);

	        return "helloworld";
	    }
	 
	@RequestMapping(value = "/delete")
	@ResponseBody
	public String delete(long id) {
		try {
			Designation designation = new Designation();
			designation.setId(id);
			designationManager.deleteDomain(designation);
		} catch (Exception ex) {
			return ex.getMessage();
		}
		return "Person succesfully deleted!";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public String create(@RequestBody Designation designation) {
		try {
			/*
			 * Person person = new Person(); person.setName(person);
			 * person.setCity(city);
			 */
			designationManager.saveDomain(designation);
		} catch (Exception ex) {
			return ex.getMessage();
		}
		return "Person succesfully saved!";
	}

	@RequestMapping(value = "/allDesignations")
	@ResponseBody
	public List<Person> getAllPersons() {
		try {
			return null;// designationManager.getAllPersons();
		} catch (Exception ex) {
			return null;
		}
	}
}