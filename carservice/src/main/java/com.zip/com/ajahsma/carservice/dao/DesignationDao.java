package com.ajahsma.carservice.dao;

public interface DesignationDao extends DefaultDao {

}
