package com.ajahsma.carservice.dao.impl;

import org.springframework.stereotype.Repository;

import com.ajahsma.carservice.dao.DesignationDao;

@Repository("myDesignationDao")
public class DesignationDaoImpl extends DefaultDaoImpl implements DesignationDao {

}
