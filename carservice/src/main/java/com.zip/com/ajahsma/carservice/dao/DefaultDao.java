package com.ajahsma.carservice.dao;

import java.io.Serializable;

import com.ajahsma.carservice.model.Domain;

public interface DefaultDao {

	Long saveDomain(Domain domain);
	
	Domain loadDomain(Class<? extends Domain> domainClass, Serializable id);
	
	Domain getDomain(Class<? extends Domain> domainClass, Serializable id);
	
	void deleteDomain(Domain domain);
	
	void updateDomain(Domain domain);
	
	public Domain get(Class<? extends Domain> domainClass, Serializable id);

}
