package com.ajahsma.carservice.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author SHARAN A
 */

@Entity
@Table(name = "insidecar")
public class InsideCar extends AbstractIdDomain {
	
//	private VehicleCustomerRegistration vehicleCustomerRegistration; 
	private Vehicle vehicle;
//	private Boolean isCheck;
	private Set<CheckNomenclatureInsideCar> checkNomenclatureInsideCars;

	/*@ManyToOne(fetch = FetchType.LAZY, cascade=CascadeType.DETACH)
	@JoinColumn(name="vehcustregtion_id", nullable=false)
	public VehicleCustomerRegistration getVehicleCustomerRegistration() {
		return vehicleCustomerRegistration;
	}

	public void setVehicleCustomerRegistration(VehicleCustomerRegistration vehicleCustomerRegistration) {
		this.vehicleCustomerRegistration = vehicleCustomerRegistration;
	}*/

	@ManyToOne(fetch = FetchType.LAZY, cascade=CascadeType.DETACH)
	@JoinColumn(name="vehicle_id", nullable=false)
	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	/*@Column(name="ischeck", nullable=false)
	public Boolean getIsCheck() {
		return isCheck;
	}

	public void setIsCheck(Boolean isCheck) {
		this.isCheck = isCheck;
	}*/

	@OneToMany(mappedBy = "insideCar", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval=true)
	public Set<CheckNomenclatureInsideCar> getCheckNomenclatureInsideCars() {
		return checkNomenclatureInsideCars;
	}

	public void setCheckNomenclatureInsideCars(Set<CheckNomenclatureInsideCar> checkNomenclatureInsideCars) {
		this.checkNomenclatureInsideCars = checkNomenclatureInsideCars;
	}

	
}
