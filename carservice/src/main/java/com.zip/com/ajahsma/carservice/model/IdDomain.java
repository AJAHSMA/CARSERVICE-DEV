package com.ajahsma.carservice.model;

/**
 * @author SHARAN A
 */

public interface IdDomain extends Domain {

	Long getId();
    void setId(Long id);
	

}
