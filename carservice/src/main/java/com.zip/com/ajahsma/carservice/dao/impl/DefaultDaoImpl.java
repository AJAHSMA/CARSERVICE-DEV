package com.ajahsma.carservice.dao.impl;

import java.io.Serializable;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.ajahsma.carservice.dao.DefaultDao;
import com.ajahsma.carservice.model.Domain;

/**
 * @author SHARAN A
 */

public class DefaultDaoImpl implements DefaultDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	private Session currentSession() {
		Session session = null;
		try {
		    session = sessionFactory.getCurrentSession();
		} catch (HibernateException e) {
		    session = sessionFactory.openSession();
		}
		return session;
	}
	
	protected Query createQuery(String queryString) {
		return currentSession().createQuery(queryString);
	}
	
	@Override
	public Domain get(Class<? extends Domain> domainClass, Serializable id) {
		Criteria criteria = createCriteria(domainClass);
		criteria.add(Restrictions.eq("id", id));
		return (Domain) criteria.list();
	}

	protected Criteria createCriteria(Class<?> persistentClass) {
		Criteria criteria = currentSession().createCriteria(persistentClass);
		return criteria;
	}

	@Override
	public Long saveDomain(Domain domain) {
		return (Long) currentSession().save(domain);
	}

	@Override
	public Domain loadDomain(Class<? extends Domain> domainClass, Serializable id) {
		
		return (Domain) currentSession().load(domainClass, id);
	}

	@Override
	public Domain getDomain(Class<? extends Domain> domainClass, Serializable id) {
		
		return (Domain) currentSession().get(domainClass, id);
	}

	@Override
	public void deleteDomain(Domain domain) {
		currentSession().delete(domain);
	}

	@Override
	public void updateDomain(Domain domain) {
		currentSession().update(domain);
		
	}


}
