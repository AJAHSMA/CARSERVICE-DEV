package com.ajahsma.carservice.service;

public interface DesignationManager extends DefaultManager {

}
