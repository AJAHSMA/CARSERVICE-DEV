package com.ajahsma.carservice.service;

import java.io.Serializable;

import com.ajahsma.carservice.model.Domain;

public interface DefaultManager {

	public Domain createNewTransientDomain(String domainClassName, Boolean isSearchMode) throws Exception;
	
	Long saveDomain(Domain domain);
	
	Domain loadDomain(Class<? extends Domain> domainClass, Serializable id);
	
	Domain getDomain(Class<? extends Domain> domainClass, Serializable id);
	
	void deleteDomain(Domain domain);
	
	void updateDomain(Domain domain);
	
	public Domain get(Class<? extends Domain> domainClass, Serializable id);

}
